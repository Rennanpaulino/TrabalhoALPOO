public class Bebida implements Produto {
    
}
