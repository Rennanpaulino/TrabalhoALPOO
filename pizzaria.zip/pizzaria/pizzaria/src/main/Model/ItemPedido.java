import Model.Pedido;
@getter
@setter

public class ItemPedido {
    private int qtd;
    private String tamanho;
    
}
