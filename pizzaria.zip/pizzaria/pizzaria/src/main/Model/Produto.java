public interface Produto {
    private String nome, descricao;
    private float valor;

    public boolean atualizarValor(float){
        return false;
    }
}
